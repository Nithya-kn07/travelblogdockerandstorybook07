import React from "react";
import App from "../App";

export default {
    title: "Test"
};

export const app = () => <App/>;
