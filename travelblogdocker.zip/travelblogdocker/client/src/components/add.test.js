import React from 'react';
import ReactDOM from 'react-dom';
import InputTravel from './InputTravel';
import EditTravel from './EditTravel';
import ListTravel from './ListTravel';

import { isTSAnyKeyword, tsExternalModuleReference } from '@babel/types';

it("renders without crasing Add button", () =>{
    const div = document.createElement("div");
    ReactDOM.render(<InputTravel></InputTravel>, div)
})

it("renders without crasing Delete button", () =>{
    const div = document.createElement("div");
    ReactDOM.render(<ListTravel></ListTravel>, div)
})

