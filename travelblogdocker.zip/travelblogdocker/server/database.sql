CREATE DATABASE newtravelblog;

CREATE TABLE newtravel(
    travel_id SERIAL PRIMARY KEY,
    description VARCHAR(300)
);
